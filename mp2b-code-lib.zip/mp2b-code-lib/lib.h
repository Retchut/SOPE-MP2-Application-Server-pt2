#ifndef _LIB_H
#define _LIB_H 1
int task(int level);
#endif // _LIB_H
